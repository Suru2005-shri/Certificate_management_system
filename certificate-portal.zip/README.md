# College Student Certificate & Involvement Management System

Open-source stack per the second SRS. **Supabase is used only as the PostgreSQL database.**

| Layer | Tool |
|---|---|
| Frontend | React + TypeScript + Vite + Tailwind |
| Backend | FastAPI (Python) |
| Database | Supabase PostgreSQL (data only) |
| Login / roles / sessions | Keycloak |
| Private file storage | MinIO |
| Certificate check | Tesseract OCR + OpenCV (assistance only) |
| Proxy / headers / rate limit | Nginx |

## What is done

**Backend (`backend/app`)** – all SRS endpoints: student register + dashboard + certificate submit/resubmit/list/detail,
teacher pending/review/approve/reject/request-resubmission/students/leaderboard adjust, HOD summary/students/certificates
(filters)/teachers/assignments/scoring rules/audit logs, class leaderboard + Student of the Month, notifications.
Security: roles and class read from the database, object-level access checks, status/score/class never taken from the client,
file type + size + signature checks, private MinIO bucket with 5-minute signed URLs, single-use teacher access codes (hashed, expiring),
HOD only via admin script, rate limiting (429 + Retry-After), security headers, audit log, no stack traces to users.

**Frontend (`frontend/src`)** – connected to the API. Keycloak sign-in (PKCE) → first-time registration (student: roll no, class, phone,
advisor shown from the database; teacher: phone + HOD access code) → role screens: dynamic certificate form with file upload, resubmission,
teacher review with signed file links and automated-check notes, class leaderboard + Student of the Month, rank change (with confirmation + reason),
HOD teacher management (one-time access code), scoring rules, audit log, notifications. Demo mode with sample data: `npm run dev:demo`.

## Not done yet (be aware)
- **Nothing has been run end to end.** The build sandbox blocked npm/pip downloads, so the frontend build, `pytest`, Docker and the Keycloak flow are untested.
  Python files compile and the scoring / certificate-check logic was tested directly. Expect small errors on first run — send them back.
- Phone/OTP verification needs a Keycloak SMS extension; the backend enforces it when `REQUIRE_PHONE_VERIFIED=true` and the token has `phone_number_verified`.
- mCaptcha: backend check exists (`MCAPTCHA_*`), but the mCaptcha server and the sign-up widget are not included.
- Keycloak's own sign-up page handles email + password; add the CAPTCHA/OTP there for abuse protection on sign-up.
- Image-only PDFs are not OCR'd (they show "Unable to read"; teacher reviews manually).
- HOD cannot open certificate files yet (teacher and student can); HOD certificate list shows the latest 200.
- Keycloak runs in dev mode in `docker-compose.yml`; use a production setup + HTTPS before going live.

## Run the demo UI only (sample data, no servers)
```
cd frontend && npm install && npm run dev:demo
```

## Run the full stack
1. Supabase: create a project, run `db/schema.sql` in the SQL editor. Create a least-privilege DB role for the app.
2. `cp .env.example .env` and fill it in.
3. `docker compose up --build`
4. Create the HOD: `DATABASE_URL=... python scripts/create_hod.py "Name" hod@college.edu 9876543210`, then sign in via Keycloak with that email (verified).
5. HOD adds teachers (returns a one-time access code) and assigns them to SE / TE / BE; the advisor shown at student sign-up comes from this assignment.
6. Tests: `cd backend && pip install -r requirements.txt && pytest`

## Before going live
HTTPS, strong secrets, separate staging/production, backups + a restore test, `npm audit` / `pip-audit`, review teacher and HOD access regularly.

## Departments (CS, AIML, IT, Civil)
- Each department has SE/TE/BE classes, its own scoring points, its own teachers and **one HOD**. An HOD sees only their own department.
- **New database:** run `db/schema.sql`. **Existing database (old IT-only data):** run `db/migrations/002_departments_and_verification.sql` once; old data becomes the IT department.
- Create one HOD per department: `python scripts/create_hod.py CS "Dr. Name" hod@college.edu 9876543210` (codes: CS, AIML, IT, CIVIL). The HOD signs in with that same verified email.
- Students choose their department at registration.

## Certificate verification (assistance only – the teacher decides)
Checked automatically: student name, event/company, year, **certificate number** (typed by the student and read from the file), the name printed after "awarded to / certify that", scanned PDFs (OCR).
Reuse/tamper hints: same file or same certificate number already used by another student, same picture re-saved/resized (perceptual hash), PDF edit traces, editor tag in image metadata, QR code (shown, never opened), weak "pasted name" texture hint.
Red-flag signals cap the score (alert → max 40%, warning → max 70%) and show "Suspicious – check carefully".
**Limits:** these are hints, not proof. A well-made forgery of a certificate nobody else submitted can pass; real proof needs the issuer's own verify link/QR. Always read the signals and decide yourself.

## Web deployment + GitHub
GitHub stores the code and builds the images (Actions → GitHub Container Registry); GitHub itself cannot run the backend. You need one small Linux server (VPS) with Docker and a domain.
1. Push this folder to a new GitHub repo (`main` branch). CI runs the tests and builds the frontend.
2. Repo → Settings → Variables: `VITE_KEYCLOAK_URL = https://auth.yourdomain` (then re-run "Build images and deploy").
3. DNS: point `portal.`, `auth.`, `files.` names at the server IP.
4. On the server: clone the repo, `cp .env.prod.example .env.prod`, fill it, then  
   `docker compose -f docker-compose.prod.yml --env-file .env.prod up -d` (HTTPS is automatic via Caddy).
5. Optional auto-deploy: add secrets `SERVER_HOST`, `SERVER_USER`, `SERVER_SSH_KEY` and variable `DEPLOY_ENABLED=true`.
6. In Keycloak (https://auth.yourdomain) create the HODs' users or let them register; run `create_hod.py` for each department.
Never commit `.env` / `.env.prod`. Keep Keycloak data: use `docker compose stop`, not `down -v`.
